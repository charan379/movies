-- 
-- Table structure for table `users`
-- 

ALTER TABLE `users` 
	CHANGE `password` `password` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;