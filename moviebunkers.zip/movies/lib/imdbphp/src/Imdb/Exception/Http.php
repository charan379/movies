<?php

namespace Imdb\Exception;

class Http extends \Imdb\Exception
{
    public $HTTPStatusCode = null;
}
