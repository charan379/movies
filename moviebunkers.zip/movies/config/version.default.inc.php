<?php
define('NEW_VERSION', '3.9.0');
define('NEW_DB_VERSION', '3.7');
