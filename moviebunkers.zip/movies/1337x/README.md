# 1337x-scrapper
A php based 1337x scrapper. For getting magnet links. Non blockable by service provider.


## Under construction. You can also Add Css by yourself. If you want any feature please comment in issue section.
